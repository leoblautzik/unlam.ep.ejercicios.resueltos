/*Confeccionar un programa para calcular la suma de los primeros N n�meros naturales.
 El valor de N lo solicita por teclado el programa.*/

#include <stdio.h>
int main()
{
    int i, suma=0, num;

    printf("Ingrese un numero positivo mayor a 0:");
    scanf("%d", &num);

    for (i=1;i<=num;i++)
        suma+=i;

    printf("La suma da: %d", suma);

    return 0;
}
