#include <stdio.h>
void VerTamanio(int[]);

int main()
{
    int vec[100];

    printf("Tamanio de vec = %d bytes", sizeof(vec));
    VerTamanio(vec);

    return 0;
}

void VerTamanio(int v[])
{
    printf("\n\nTamanio de v en la funcion = %d bytes", sizeof(v));
}
